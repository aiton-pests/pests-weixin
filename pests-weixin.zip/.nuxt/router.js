import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _489ac6fe = () => interopDefault(import('..\\pages\\trap.vue' /* webpackChunkName: "pages/trap" */))
const _52da300e = () => interopDefault(import('..\\pages\\view.vue' /* webpackChunkName: "pages/view" */))
const _75066426 = () => interopDefault(import('..\\pages\\viewtrap.vue' /* webpackChunkName: "pages/viewtrap" */))
const _2c0af4ae = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/trap",
    component: _489ac6fe,
    name: "trap"
  }, {
    path: "/view",
    component: _52da300e,
    name: "view"
  }, {
    path: "/viewtrap",
    component: _75066426,
    name: "viewtrap"
  }, {
    path: "/",
    component: _2c0af4ae,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
